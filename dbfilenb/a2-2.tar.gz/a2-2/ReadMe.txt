COP6726 DBFile submission

Team -- 
Sandesh Ashok Ingale  80919933
Mustaqim Moulavi   118479996

Modifications Made to test.cc

Some code that does not get compiled contains my own test cases

Added options for missing tables in the list.

