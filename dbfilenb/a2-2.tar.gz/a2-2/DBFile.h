#ifndef DBFILE_H
#define DBFILE_H

#include "Pipe.h"
#include "BigQ.h"
#include "TwoWayList.h"
#include "Record.h"
#include "Schema.h"
#include "File.h"
#include "Comparison.h"
#include "ComparisonEngine.h"
#include <iostream>
#include <stdio.h>
#include <vector>
#include<cstdlib>
#include<time.h>
#include <algorithm>

typedef enum {
    heap, sorted, tree
} fType;

typedef enum {
    reading, writing
} Mode;

// Structure to store the meta data of DBFile

typedef struct MetaInfo {
    // Type of the file {heap, sorted, tree}
    fType fileType;
} Meta;

struct SortInfo {
OrderMaker *myOrder;
int runLength;
};

// stub DBFile header..replace it with your own DBFile.h

class GenericDBFile {
protected:
    //Page that was currently written
    off_t writePage;

    //Current Record Pointer
    off_t curRec;

    //Current Page
    off_t curPage;

    //Number of Pages in File
    off_t numPages;

    //File Object that will be used to store the Pages on the disk
    File diskFile;

    //In Memory Page that will hold the records until they are written out
    Page inPage,writePage1;

    //Meta Data Object
    Meta fileInfo;

    //Temporarily Store the Path of the File
    char *filePath;

    //Temporarily Store the Path of the File
    char *metaFileName;



public:
    //Creates a new DBFile
    //fpath- path at which the file is to be placed.
    //filetype - either heap, sorted, tree   This will decide the implementation
    //returns -1 if file was not created.
    virtual int Create(char *fpath, fType file_type, void *startup) = 0;

    //Opens an existing file
    virtual int Open(char *fpath) = 0;
    virtual  int Close() = 0;

    virtual void Load(Schema &myschema, char *loadpath) = 0;

    virtual void MoveFirst() = 0;
    virtual void Add(Record &addme) = 0;
    virtual int GetNext(Record &fetchme) = 0;
    virtual int GetNext(Record &fetchme, CNF &cnf, Record &literal) = 0;

    //Scramble File -- This function is just for testing purpose
    void scramble(Schema*);

};

class HeapDBFile: public GenericDBFile 
{

public:

    HeapDBFile();

    //Creates a new DBFile
    //fpath- path at which the file is to be placed.
    //filetype - either heap, sorted, tree   This will decide the implementation
    //returns -1 if file was not created.
    int Create(char *fpath, fType file_type, void *startup);

    //Opens an existing file
    int Open(char *fpath);
    int Close();

    void Load(Schema &myschema, char *loadpath);

    void MoveFirst();
    void Add(Record &addme);
    int GetNext(Record &fetchme);
    int GetNext(Record &fetchme, CNF &cnf, Record &literal);

};

class SortedDBFile: public GenericDBFile {
private:
    SortInfo *mySortInfo;
    Mode fileMode;
    Pipe *input;
    Pipe *output;
    
public:

    SortedDBFile();

    //Creates a new DBFile
    //fpath- path at which the file is to be placed.
    //filetype - either heap, sorted, tree   This will decide the implementation
    //returns -1 if file was not created.
    int Create(char *fpath, fType file_type, void *startup);

    //Opens an existing file
    int Open(char *fpath);
    int Close();

    void Load(Schema &myschema, char *loadpath);

    void MoveFirst();
    void Add(Record &addme);
    int GetNext(Record &fetchme);
    int GetNext(Record &fetchme, CNF &cnf, Record &literal);

};

class DBFile {

private:
    
    GenericDBFile *myInternalVar;
    
public:

    //DBFile();

    //Creates a new DBFile
    //fpath- path at which the file is to be placed.
    //filetype - either heap, sorted, tree   This will decide the implementation
    //returns -1 if file was not created.
    int Create(char *fpath, fType file_type, void *startup);

    //Opens an existing file
    int Open(char *fpath);
    int Close();

    void Load(Schema &myschema, char *loadpath);

    void MoveFirst();
    void Add(Record &addme);
    int GetNext(Record &fetchme);
    int GetNext(Record &fetchme, CNF &cnf, Record &literal);

};

#endif